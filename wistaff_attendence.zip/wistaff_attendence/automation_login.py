import os
from datetime import datetime
from time import sleep
from selenium import webdriver
from PIL import Image
import mysql.connector
import pysftp
import cv2
from webdriver_manager.chrome import ChromeDriverManager

captchaPath = r"C:\Users\AS20127712\PycharmProjects\DEVELOPMENT\wistaff_attendence\captcha/"

login = False

while(not login):

    driver = webdriver.Chrome(ChromeDriverManager().install())

    driver.maximize_window()

    driver.get("https://hr.wistaff.in/Default.aspx")

    sleep(5)

    driver.find_element_by_id("UserName").send_keys("20127712")
    driver.find_element_by_id("PasswordText").send_keys("aNSHU@580")

    driver.save_screenshot(f"{captchaPath}/full_screen.jpg")

    img = cv2.imread(f"{captchaPath}/full_screen.jpg")
    captcha = img[401:482, 570:770]
    gray = cv2.cvtColor(captcha, cv2.COLOR_BGR2GRAY)
    thresh = cv2.threshold(gray, 0, 255, cv2.THRESH_BINARY_INV + cv2.THRESH_OTSU)[1]
    cv2.imwrite(f"{captchaPath}/cap.png", thresh)

    sleep(5)

    cmd = f"tesseract cap.png captcha"
    os.chdir(captchaPath)
    os.system(cmd)

    with open("captcha.txt") as fp:
        line = fp.readline()
        captchaResult = line[:6]
        captchaResult = captchaResult.upper()
        fp.close()

    print(f"Captcha : {captchaResult}")

    driver.find_element_by_id('captchTxt').send_keys(captchaResult)

    sleep(2)

    loginbt = driver.find_element_by_id('btnLogin')

    driver.execute_script("arguments[0].click();", loginbt)

    currentURL = driver.current_url

    if currentURL != "https://hr.wistaff.in/Default.aspx":
        print("Success")
        login = True

        driver.get('https://hr.wistaff.in/hrms/pages/ViewAttendanceList.aspx')

        driver.find_element_by_id('lnkcheckIn').click()

        sleep(4)

        driver.close()

    else:

        print("Failed")
        driver.close()
        sleep(2)











#driver.close()